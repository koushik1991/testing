<?php
$a=$_POST['t1'];
$a;
$i;

if($a%2==0)
for($i=2;$i<$a;$i++)

echo " Entered number is  not prime ";

if($a%2!==0)

echo  "Entered number is prime";
for($i=2;$i<$a;$i++)	

?>
