<!DOCTYPE html>
<head>
    <title>
        piku.com
    </title>
</head>
<body>
   <form method="post" action="ans.php">

        <table border="3">
            <tr>
                <td>
                    enter year
                    </td>
            <td>
                <input type="text" name="t1"/>
                </td>
            </tr>
            <tr>
            <td>
            <input type ="submit"  value ="submit"/>
                   
            </td>
            </tr>
        </table>
    </form>
</body>
</html>