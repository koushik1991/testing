<!DOCTYPE html>
<head>
    <title>
        prime number.com
    </title>
</head>
<body>
   <form method="post" action="prime.php">

        <table border="3">
            <tr>
                <td>
                    enter no to check prime or not 
                    </td>
            <td>
                <input type="text" name="t1"/>
                </td>
            </tr>
            <tr>
            <th colspan="2">
            <input type ="submit"  value ="submit"/>
                   
            </th>
            </tr>
        </table>
    </form>
</body>
</html>